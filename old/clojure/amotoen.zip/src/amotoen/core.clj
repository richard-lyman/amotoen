(ns amotoen.core)

(defn -main
  "I don't do a whole lot."
  [& args]
  (println "Hello, World!"))
